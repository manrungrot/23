# INSTALL WITH TERMUX
 
1. `termux-setup-storage`
 
2. `cd /sdcard`
 
3. `apt update && apt upgrade -y && apt install python -y && apt install git -y`
 
4. `git clone https://github.com/tinnakorn941/P3.git`
 
5. `cd p3 && python -m pip install -r pip.txt && python3 jo.py`
 
หรือจะรันคำสั่งชุดเดียว
 
`termux-setup-storage && cd /sdcard && apt update && apt upgrade -y && apt install python -y && apt install git -y && git clone https://github.com/Grueta/P3.git && cd p3 && python -m pip install -r pip.txt && python p3.py`
 
 
ครั้งต่อไปเข้าแอพ Termux ใช้คำสั่ง 

`cd /sdcard/p3 && python3 p3.py`

Credit :`https://github.com/paokoonza/3`
 
มาร่วมแบ่งปันความรู้หรือสอบถามกันได้ที่สแควร์

https://line.me/ti/g2/OXNFJ5K4P9
